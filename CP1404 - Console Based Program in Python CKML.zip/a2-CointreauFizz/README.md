# CP1404/5632 Assignment: Songs To Learn by:
 NAME: Celina Kaesar M. Lumain
 JCU Student ID: 13370770

_Edit this README, replacing this line and above with your own assignment details._  
_At the end of the project, complete the project reflection below by answering the questions (replace the ... parts)._
_Note that to get full marks for this, your reflection should match the "exemplary" description from the rubric:_

> The project reflection is complete and describes development and learning well, shows careful thought, highlights insights made during code development.


## 1. How long did the entire project (assignment 2) take you?

> It took me 3 days to do assignment 02.

> It’s important to read and understand the Assignment’s pre-reading before the actual Assignment 02 which was
coding out the Kivy’s GUI.

> 1st day - 2nd day: The first few hours were spend to create re-usable data types that simplify and modularize the
program by using the Classes that was provided in the assignment with my own improvisation of the code.

> I first started out with the design, hence the pseudocode to make it easier for me to code it out (designed the
pseudocode through the “scratch file” in Pycharm Editor). Once I’m done, I begin it by doing the actual code.

> It took me like almost 5 hours just to get the code right because I faced a lot of coding errors along the way.
These errors made me think and reflect so hard it almost burned my brains out.

> I completed some simple testing with the code I developed in my song and SongList classes. I was able to use one
of the things that was provided/mentioned in the lectures which was ASSERT when testing for the test_song.py for
empty song, initial-value song, and test mark_learned() and conducted some tests for each method of each class one
at a time to make sure the program runs smoothly, which it did – YES!.

> On a positive note, every successful implementation or correct code I made and that runs successfully is committed
and push to the master branch in GitHub.

> 2nd-3rd day: After knowing that both classes are working well, I then proceed to creating the code for the Kivy
GUI’s application, conducted some tests again to make sure the program runs smoothly, and made some minor changes
to the code to make sure it was specifically made for the rubrics (hopefully it is). I managed to finish my
reflection on time too.

Note: You may like to use the WakaTime plugin, which tracks exactly how long you spend in code. See http://wakatime.com (but note that the free version only has a 7-day history)



## 2. What are you most satisfied with?

> I find satisfaction when I perform over my expectations. I feel happy and satisfied when I am able to solve hard
problems such as coding out the main.py and app.kv and it runs smoothly (with no errors).

> Every time a test runs smoothly, I feel ecstatic to commit my work in Github. And the best code, is always the one
that works (at least in my opinion).

> The feeling of happiness is still there and it follows me whenever I think about it, inspiring me to do better in
my code, making me a better programmer. It’s always a good start if you know the basics and a thorough understanding
of Python (classes, methods, functions, symbols etc.) and having a better understanding of how a GUI works.

> Kivy is not the only GUI that can be use in Python, so it’s best if you always have prepared knowledge about it.



## 3. What are you least satisfied with?

> I feel the magnitude of dissatisfaction when I realize I have less knowledge trying to figure out the solution to
those problems (e.g. errors every time I test my application) and there is something wrong buried in the code
somewhere and I am unfamiliar how to fork it out.

> It is alright for me to feel dissatisfied at times because the feeling of dissatisfaction inspires me to grow
better, to become curious and to also (and hopefully one day) make me a better programmer.



## 4. What worked well in your development process?

> I believe that it’s always best to get a hindsight of what the requirements are and it is of constant good practice
to understand what you need to do, how you are going to implement it before you actually start coding it out.

> Everything needs to be done in steps. Programming requires a lot of patience. By having sufficient understanding
about the problem will save you a lot of time and it will help you become more efficient when coding things out.

> This not just only happen in assignments but also in the real world when you are achieving to become a
programmer someday.

> In my case (as for the assignment), it’s best to read the assignment’s pre-reading which is starting out with
the classes. You have to code them out first and then having each method, class, function, etc. tested out and
make sure it works well before diving in and coding out the Kivy application.

> By studying the existing code that I have made errors with together with me providing the solution to fix those
errors, I can distance myself from my code and see a completely different train of thought. This helps me
understand the strengths and weaknesses of my original logic and proceed from there.



## 5. What about your process could be improved the next time you do a project like this?

> Since the dawn of the computer era, programmers and bugs have battled for supremacy. It's an inevitable occurrence.
Even the greatest programmers fall prey to these anomalies. No code is safe. That's why we do testing.

> The next time I have been given a project (whether at work or at university), it’s always remember to remember
these 5 processes:

> 1. First process is that before writing any code, one must think very abstractly about the data he/she is working
with and what data structures or certain class, methods, functions that will be useful. This could also be in a
form of pseudocodes wherein it helps to describe the larger processes that would result in a large amounts of code
to keeping it in a shorter overview of it.

> 2. Start coding or doing the actual code.

> 3. Start testing the code. The first time running the program will surely encounter a lot of errors,
which is fine because this indicates that the code is not ready yet.

> 4. Understand what the errors are, then find the solution to those errors. Run the program again. Keep coding
until the code can be fixed and passes all the assertions and until the program can run successfully.

> 5. Once the code can successfully run, then begin cleaning it up through formatting and refractoring and still
do some tests if the program still works. Once everything works well, it’s then to commit to Github. That said,
it is best to commit and push to the working code, whilst the code that’s still undergoing development can be
push to branch first.



## 6. Describe what resources you used and how you used them.

> The sources I used were the lecture slides in my programming class together with the exercises used during
the practicals. I also used a few code demos (those extension works) for reference.

> I also did Google for certain programming terms I have not come across with or that were not mentioned
in the lecture (perhaps, they were a bit too advance). I did some coding practice too by watching some Youtube
videos on how to do it before I started doing the actual assignment just to familiarize myself and be comfortable
with it, especially the Kivy GUI (hence, active learning here).



## 7. Describe the main challenges or obstacles you faced and how you overcame them.
> One of the main challenges or obstacles that I have faced during the development process was getting my Kivy
application to work and make it look exactly like the assignment’s screenshot.

> I was overwhelmed at first because of my lack of knowledge and familiarization with the kivy’s feature since
> I have never encountered this GUI before. But after diving in-depth about Kivy and getting acquainted on how to
code it out, I managed to overcome my fear and really focus on getting my application to work.