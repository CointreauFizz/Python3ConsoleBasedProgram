"""
Name: Celina Kaesar M. Lumain
Date: July 31 1990
Brief Project Description:
The project is about Creating a Graphical User Interface (GUI) program similar to that of the previous assignment (A1),
using Python 3 and the Kivy toolkit.
GitHub URL: https://github.com/CointreauFizz
"""

# Create your main program in this file, using the SongsToLearnApp class

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.properties import StringProperty
from songlist import SongList
from song import Song


class SongsToLearnApp(App):
    status_message = StringProperty()
    required_text = StringProperty()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_song_list = SongList()
        self.user_song_list.load_songs("songs.csv")
        self.song_list = self.user_song_list.songs
        self.sort_options = ["title", "artist", "year", "is_required"]
        self.current_sort = self.sort_options[2]

    def build(self):
        self.title = "Songs To Learn 2.0"
        self.root = Builder.load_file('app.kv')
        self.create_widgets()
        return self.root

    def create_widgets(self):
        learned_songs = self.user_song_list.get_number_of_learned_songs()
        required_songs = self.user_song_list.get_number_of_required_songs()
        for song in self.song_list:
            title = song.title
            artist = song.artist
            year = song.year
            learned = song.is_required
            if learned is False:
                text_title = '"{}" by {} ({}) (Learned)'.format(title, artist, year)
                button_color = [1, 1, 0, 1]
            else:
                text_title = '"{}" by {} ({})'.format(title, artist, year)
                button_color = [0, 1, 1, 1]
            temp_button = Button(text=text_title, id=song.title, background_color=button_color)
            temp_button.bind(on_release=self.press_button)
            self.root.ids.entries_box.add_widget(temp_button)
        self.required_text = "To learn: {}, Learned: {}".format(required_songs, learned_songs)

    def press_button(self, instance):
        name = instance.id
        Song1 = self.user_song_list.get_song_by_title(name)
        if Song1.is_required is False:
            self.status_message = "You have marked '{}' as required".format(Song1.title)
            Song1.mark_learned(True)
        else:
            self.status_message = "You have marked '{}' as learned".format(Song1.title)
            Song1.mark_learned(False)
        self.root.ids.entries_box.clear_widgets()
        self.create_widgets()

    def add_song(self):
        title = self.root.ids.input_title.text
        artist = self.root.ids.input_artist.text
        year = self.root.ids.input_year.text
        check_status = self.error_check(title, artist, year)
        if check_status is True:
            self.clear_all()
            new_song = Song(title.title(), artist.title(), year)
            self.user_song_list.add_song(new_song)
            self.song_list = self.user_song_list.songs
            self.status_message = "You have added '{}' by {} ({})".format(new_song.title, new_song.artist,
                                                                          new_song.year)
            widget_message = '"{}" by {} ({})'.format(new_song.title, new_song.artist, new_song.year)
            temp_button = Button(text=widget_message, id=new_song.title, background_color=[0, 1, 1, 1])
            temp_button.bind(on_release=self.press_button)
            self.root.ids.entries_box.add_widget(temp_button)
            learned_songs = self.user_song_list.get_number_of_learned_songs()
            required_songs = self.user_song_list.get_number_of_required_songs()
            self.required_text = "To learn: {}. Learned: {}".format(required_songs, learned_songs)

    def clear_all(self):
        self.root.ids.input_title.text = " "
        self.root.ids.input_artist.text = " "
        self.root.ids.input_year.text = " "
        self.status_message = " "

    def change_sort(self, sorting_choice):
        self.status_message = "Songs have been sorted by: {}".format(sorting_choice)
        self.user_song_list.sort(sorting_choice)
        self.song_list = self.user_song_list.songs
        self.root.ids.entries_box.clear_widgets()
        self.create_widgets()
        sort_index = self.sort_options.index(sorting_choice)
        self.current_sort = self.sort_options[sort_index]

    def on_stop(self):
        self.user_song_list.save_to_csv()

    # Added Error checking feature to check and notify the user in case of wrong input:

    def error_check(self, title, artist, year):
        try:
            if not title:
                self.status_message = "ERROR: All Inputs Must be Correct! Check Again!"
                raise ValueError()
            if not artist:
                self.status_message = "ERROR: All Inputs Must be Correct! Check Again!"
                raise ValueError()
            if not year:
                self.status_message = "ERROR: All Inputs Must be Correct! Check Again!"
                raise ValueError()
        except ValueError:
            return False
        try:
            int(year)
        except ValueError:
            self.status_message = "ERROR: Must be a VALID number"
            return False
        try:
            if not int(year) > 0:
                self.status_message = "ERROR: Must be a VALID number"
                raise ValueError()
        except ValueError:
            return False
        return True

    pass


SongsToLearnApp().run()
