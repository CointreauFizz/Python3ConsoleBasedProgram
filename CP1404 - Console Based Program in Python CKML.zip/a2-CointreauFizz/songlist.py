# create your SongList class in this file

import csv
from song import Song
from operator import attrgetter


def read_from_csv(csv_file):
    with open(csv_file, 'r') as f:
        reader = csv.reader(f)
        return list(reader)


class SongList:
    def __init__(self):
        self.songs = []

    def load_songs(self, csv_file):
        song_array = read_from_csv(csv_file)
        for row in song_array:
            if row[3] == 'n':
                song = Song(row[0], row[1], row[2], True)
            else:
                song = Song(row[0], row[1], row[2], False)
            self.songs.append(song)

    def get_song_by_title(self, title):
        for song in self.songs:
            if song.title == title:
                return song
        return None

    def add_song(self, song):
        self.songs.append(song)

    def get_number_of_required_songs(self):
        required = 0
        for song in self.songs:
            if song.is_required is True:
                required += 1
        return required

    def get_number_of_learned_songs(self):
        learned = 0
        for song in self.songs:
            if song.is_required is False:
                learned += 1
        return learned

    def save_to_csv(self, output_file_name='songs_saved.csv'):
        with open(output_file_name, 'w') as f:
            writer = csv.writer(f)
            for song in self.songs:
                row = [song.title, song.artist, song.year, 'y' if (song.is_required is True) else 'n']
                writer.writerow(row)

        f.close()

    def sort(self, key):
        self.songs = sorted(self.songs, key=attrgetter(key, 'title'))

    def __str__(self):
        list_index = 1
        string_for_print = "Song List:\n"
        for song in self.songs:
            string_for_print = string_for_print + "{}. {} {:<30} - {:<30} ({})\n".format(str(list_index),
                                                                                         "*" if
                                                                                         (song.is_required is False)
                                                                                         else " ",
                                                                                         song.title, song.artist,
                                                                                         song.year)
            list_index += 1
        return string_for_print

    pass
