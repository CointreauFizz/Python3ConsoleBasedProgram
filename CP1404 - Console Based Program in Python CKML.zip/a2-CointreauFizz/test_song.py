"""(Incomplete) Tests for Song class."""
from song import Song

# test empty song (defaults)
song = Song()
assert song.artist == ""
assert song.title == ""
assert song.year == 0
assert song.is_required

# test initial-value song
song2 = Song("Amazing Grace", "John Newton", 1779, True)
assert song2.title == "Amazing Grace"
assert song2.artist == "John Newton"
assert song2.year == 1779
assert song2.is_required

# test mark_learned()
# TODO: write tests to show the mark_learned() method works
song3 = Song("Amazing Grace", "Tim Newton", 1800, True)
assert song3.is_required is True
song3.mark_learned()
assert song3.is_required is False


