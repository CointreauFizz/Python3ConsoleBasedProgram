"""
(incomplete) Tests for SongList class
"""
from songlist import SongList
from song import Song

# test empty SongList
song_list = SongList()
assert len(song_list.songs) == 0

# test loading songs
song_list.load_songs('songs.csv')
assert len(song_list.songs) == 6  # assuming CSV file is not empty

# TODO: add tests below to show the various required methods work as expected
# test sorting songs
song_list.sort('year')

# test adding a new Song
new_song = Song("Amazing Grace", "John Newton", 1779, True)
song_list.add_song(new_song)
print(song_list)

newly_added_song = song_list.get_song_by_title('Amazing Grace')
assert newly_added_song is not None
assert newly_added_song.title == 'Amazing Grace'
assert newly_added_song.artist == 'John Newton'
assert newly_added_song.year == 1779
assert newly_added_song.is_required

# test get_song()
song1 = song_list.get_song_by_title('Happy Birthday')
assert song1 is None

song2 = song_list.get_song_by_title('Somebody That I Used to Know')
assert song2 is not None
assert song2.title == 'Somebody That I Used to Know'


# test getting the number of required and learned songs (separately)
requiredCount = song_list.get_number_of_required_songs()
assert requiredCount > 0
assert requiredCount == 3

learnedCount = song_list.get_number_of_learned_songs()
assert learnedCount > 0
assert learnedCount == 4

# test saving songs (check CSV file manually to see results)
song_list.save_to_csv()
